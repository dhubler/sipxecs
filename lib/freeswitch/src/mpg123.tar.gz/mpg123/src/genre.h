/*
	genre: id3 genre definition

	copyright ?-2007 by the mpg123 project - free software under the terms of the LGPL 2.1
	see COPYING and AUTHORS files in distribution or http://mpg123.org
	initially written by Shane Wegner
*/

#ifndef _MPG123_GENRE_H_
#define _MPG123_GENRE_H_

extern char *genre_table[];
extern const int genre_count;

#endif
