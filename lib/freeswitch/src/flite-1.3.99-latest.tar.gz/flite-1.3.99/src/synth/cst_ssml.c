/*************************************************************************/
/*                                                                       */
/*                  Language Technologies Institute                      */
/*                     Carnegie Mellon University                        */
/*                      Copyright (c) 2001-2008                          */
/*                        All Rights Reserved.                           */
/*                                                                       */
/*  Permission is hereby granted, free of charge, to use and distribute  */
/*  this software and its documentation without restriction, including   */
/*  without limitation the rights to use, copy, modify, merge, publish,  */
/*  distribute, sublicense, and/or sell copies of this work, and to      */
/*  permit persons to whom this work is furnished to do so, subject to   */
/*  the following conditions:                                            */
/*   1. The code must retain the above copyright notice, this list of    */
/*      conditions and the following disclaimer.                         */
/*   2. Any modifications must be clearly marked as such.                */
/*   3. Original authors' names are not deleted.                         */
/*   4. The authors' names are not used to endorse or promote products   */
/*      derived from this software without specific prior written        */
/*      permission.                                                      */
/*                                                                       */
/*  CARNEGIE MELLON UNIVERSITY AND THE CONTRIBUTORS TO THIS WORK         */
/*  DISCLAIM ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING      */
/*  ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT   */
/*  SHALL CARNEGIE MELLON UNIVERSITY NOR THE CONTRIBUTORS BE LIABLE      */
/*  FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES    */
/*  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN   */
/*  AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,          */
/*  ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF       */
/*  THIS SOFTWARE.                                                       */
/*                                                                       */
/*************************************************************************/
/*             Author:  Alan W Black (awb@cs.cmu.edu)                    */
/*               Date:  June 2008                                        */
/*************************************************************************/
/*                                                                       */
/*  SSML support for flite ( http://www.w3.org/TR/speech-synthesis/ )    */
/*                                                                       */
/*  We don't use a full XML parser here for space and availability       */
/*  reasons, but this is adequate for SSML                               */
/*  This is based on some old SABLE support in flite that never got      */
/*  completed                                                            */
/*                                                                       */
/*  <ssml> </ssml>                                                       */
/*  <phoneme ph="x x x"> </phoneme>                                      */
/*  <voice ...> </voice>                                                 */
/*  <audio ...> </audio>                                                 */
/*  <emphasis ...> </emphasis>                                           */
/*  <break .../>                                                         */
/*  <prosody ...> </prosody>  pitch rate duration volume                 */
/*  <!-- ... -->                                                         */
/*                                                                       */
/*  <...> ignore all others                                              */
/*************************************************************************/

#include "flite.h"
#include "cst_tokenstream.h"

static const char *ssml_whitespacesymbols;
static const char *ssml_singlecharsymbols;

#if 0

static void add_raw_data(cst_utterance *u, const char *raw_data,
			 cst_features *attributes)
{
    /* Add all tokens in raw _data to u */
    cst_tokenstream *ts;
    cst_relation *r;
    cst_item *t;
    const char *token;

    r = utt_relation_create(u,"Token");
    ts = 
     ts_open_string(raw_data,
                    get_param_string(u->features,"text_whitespace",NULL),
                    get_param_string(u->features,"text_singlecharsymbols",NULL),
                    get_param_string(u->features,"text_prepunctuation",NULL),
                    get_param_string(u->features,"text_pospunctuation",NULL));
    while (!(ts_eof(ts)))
    {
	t = relation_append(r,NULL);
	feat_copy_into(item_feats(t),attributes);
	token = ts_get(ts);
	if (cst_strlen(token) > 0)
	{
	    t = relation_append(r,NULL);
	    item_set_string(t,"name",token);
	    item_set_string(t,"whitespace",ts->whitespace);
	    item_set_string(t,"prepunctuation",ts->prepunctuation);
	    item_set_string(t,"punc",ts->postpunctuation);
	}
    }

}

static cst_utterance *end_utt(cst_utterance *u)
{
    /* Synthesize current utterance and generate a new one */
    cst_utterance *u2;

    utt_synth_tokens(u);

    u2 = new_utterance();
    /* copy over the current ssml tag context */

    delete_utterance(u);
    
    utt_relation_create(u2,"Token");
    return u2;
}

static const char *ts_get_quoted_remainder(cst_tokenstream *ts)
{
    get_token_subv_part_2(ts,
			 "\"",
			 &ts->token,
			 &ts->token_max);
    ts_get(ts);  /* skip the quote */
    if (ts_eof(ts))
	return 0;
    else
	return ts->token;
}

static cst_features *ssml_get_attributes(cst_tokenstream *ts)
{
    cst_features *a = new_features();
    const char* name, *val;

    set_charclasses(ts,
                    ts->p_whitespacesymbols,
                    "=>;/\"",
                    ts->p_prepunctuationsymbols,
                    ts->p_postpunctuationsymbols);
                    
    while (!cst_streq(">",ts_get(ts)))
    {
	name = ts_get(ts);
	if (cst_streq(name,"/"))
	    feat_set_string(a,"_type","startend");
	else
	{
	    feat_set_string(a,"_type","start");
	    if (!cst_streq("=",ts_get(ts)))
	    {
		delete_features(a);
		fprintf(stderr,"ssml: expected \"=\"\n");
		return 0;
	    }
	    val = ts_get(ts);
	    if (!cst_streq(val,"\""))
	    {
		delete_features(a);
		fprintf(stderr,"ssml: expected quoted value\n");
		return 0;
	    }
	    val = ts_get_quoted_remainder(ts);
	    if (val == 0)
	    {
		delete_features(a);
		return 0;
	    }
	    feat_set_string(a,cst_strdup(name),val); /* FIXME leak will be gc'd */
	}
	if (ts_eof(ts))
	{
	    fprintf(stderr,"ssml: unexpected EOF\n");
	    delete_features(a);
	    return 0;
	}
    }
	
    set_charclasses(ts,
                    ts->p_whitespacesymbols,
                    "<&",
                    ts->p_prepunctuationsymbols,
                    ts->p_postpunctuationsymbols);

    return a;
}

static cst_utterance *ssml_apply_tag(const char *tag,
                                     cst_features *attributes,
                                     cst_utterance *u,
                                     cst_features *word_feats)
{
    printf("TAG %s\n",tag);
    feat_print(stdout,attributes);

    /* do stuff */

    return end_utt(u);
}
			       
static void extend_buffer(char **buffer,int *buffer_max,int at_least)
{
    int new_max;

    new_max = (*buffer_max)+at_least;
    cst_free(*buffer);
    *buffer = cst_alloc(char,new_max);
    *buffer_max = new_max;
}			  

float flite_ssml_to_speech(cst_tokenstream *ts,
                           cst_voice *voice,
                           const char *outtype)
{
    cst_features *ssml_feats, *ssml_word_feats;
    cst_features *attributes;
    const char *token;
    char *tag;
    cst_utterance *u;
    char *rawdata;
    int rawdata_size;

    rawdata_size = 20;
    rawdata = cst_alloc(char,20);
    rawdata[0] = '\0';

    ssml_feats = new_features();
    ssml_word_feats = new_features();
    set_charclasses(ts,
                    " \t\n\r",
                    "<>&\";",
                    "",
                    "");

    u = utt_init(new_utterance(),voice);

    while (!ts_eof(ts))
    {
	token = ts_get(ts);
	if (cst_streq("<",token))
	{   /* A tag */
	    add_raw_data(u,rawdata,ssml_word_feats);
	    rawdata = 0; rawdata_size = 0;
	    tag = cst_upcase(ts_get(ts));
	    attributes = ssml_get_attributes(ts);
	    u = ssml_apply_tag(tag,attributes,u,ssml_word_feats);
	    cst_free(tag);
	}
	else if (cst_streq("&",token))
	{   /* an escape sequence */
	    /* skip to ; and insert value in rawdata */
	}
	else 
	{   /* raw data */
	    /* add to char *rawdata */
	    if (cst_strlen(rawdata)+cst_strlen(token) >= rawdata_size)
		extend_buffer(&rawdata,&rawdata_size,cst_strlen(token));
	    strcat(rawdata,token);
	}
    }

    ts_close(ts);
    return 0.0;
}

#endif
