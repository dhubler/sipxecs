/*************************************************************************/
/*                                                                       */
/*                  Language Technologies Institute                      */
/*                     Carnegie Mellon University                        */
/*                         Copyright (c) 2007                            */
/*                        All Rights Reserved.                           */
/*                                                                       */
/*  Permission is hereby granted, free of charge, to use and distribute  */
/*  this software and its documentation without restriction, including   */
/*  without limitation the rights to use, copy, modify, merge, publish,  */
/*  distribute, sublicense, and/or sell copies of this work, and to      */
/*  permit persons to whom this work is furnished to do so, subject to   */
/*  the following conditions:                                            */
/*   1. The code must retain the above copyright notice, this list of    */
/*      conditions and the following disclaimer.                         */
/*   2. Any modifications must be clearly marked as such.                */
/*   3. Original authors' names are not deleted.                         */
/*   4. The authors' names are not used to endorse or promote products   */
/*      derived from this software without specific prior written        */
/*      permission.                                                      */
/*                                                                       */
/*  CARNEGIE MELLON UNIVERSITY AND THE CONTRIBUTORS TO THIS WORK         */
/*  DISCLAIM ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING      */
/*  ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT   */
/*  SHALL CARNEGIE MELLON UNIVERSITY NOR THE CONTRIBUTORS BE LIABLE      */
/*  FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES    */
/*  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN   */
/*  AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,          */
/*  ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF       */
/*  THIS SOFTWARE.                                                       */
/*                                                                       */
/*************************************************************************/
/*             Author:  Alan W Black (awb@cs.cmu.edu)                    */
/*               Date:  November 2007                                    */
/*************************************************************************/
/*                                                                       */
/*  Some language independent features                                   */
/*                                                                       */

#include "cst_hrg.h"
#include "cst_phoneset.h"
#include "cst_regex.h"

const cst_val *ph_vc(const cst_item *p)
{
    return phone_feature(item_phoneset(p),item_name(p),"vc");
}
const cst_val *ph_vlng(const cst_item *p)
{
    return phone_feature(item_phoneset(p),item_name(p),"vlng");
}
const cst_val *ph_vheight(const cst_item *p)
{
   return phone_feature(item_phoneset(p),item_name(p),"vheight");
}
const cst_val *ph_vrnd(const cst_item *p)
{
    return phone_feature(item_phoneset(p),item_name(p),"vrnd");
}
const cst_val *ph_vfront(const cst_item *p)
{
    return phone_feature(item_phoneset(p),item_name(p),"vfront");
}
const cst_val *ph_ctype(const cst_item *p)
{
    return phone_feature(item_phoneset(p),item_name(p),"ctype");
}
const cst_val *ph_cplace(const cst_item *p)
{
    return phone_feature(item_phoneset(p),item_name(p),"cplace");
}
const cst_val *ph_cvox(const cst_item *p)
{
    return phone_feature(item_phoneset(p),item_name(p),"cvox");
}

const cst_val *cg_duration(const cst_item *p)
{
    /* Note this constructs float vals, these will be freed when the */
    /* cart cache is freed, so this should only be used in carts     */
    if (!p)
        return float_val(0.0);
    else if (!item_prev(p))
        return item_feat(p,"end");
    else
        return float_val(item_feat_float(p,"end")
			 - item_feat_float(item_prev(p),"end"));
}

DEF_STATIC_CONST_VAL_STRING(val_string_pos_b,"b");
DEF_STATIC_CONST_VAL_STRING(val_string_pos_m,"m");
DEF_STATIC_CONST_VAL_STRING(val_string_pos_e,"e");

const cst_val *cg_state_pos(const cst_item *p)
{
    const char *name;
    name = item_feat_string(p,"name");
    if (!cst_streq(name,ffeature_string(p,"p.name")))
        return (cst_val *)&val_string_pos_b;
    if (cst_streq(name,ffeature_string(p,"n.name")))
        return (cst_val *)&val_string_pos_m;
    else
        return (cst_val *)&val_string_pos_e;
}

const cst_val *cg_state_place(const cst_item *p)
{
    float start, end;
    int this;
    start = (float)ffeature_int(p,"R:mcep_link.parent.daughter1.frame_number");
    end = (float)ffeature_int(p,"R:mcep_link.parent.daughtern.frame_number");
    this = item_feat_int(p,"frame_number");
    if ((end-start) == 0.0)
        return float_val(0.0);
    else
        return float_val((this-start)/(end-start));
}

const cst_val *cg_state_index(const cst_item *p)
{
    float start;
    int this;
    start = (float)ffeature_int(p,"R:mcep_link.parent.daughter1.frame_number");
    this = item_feat_int(p,"frame_number");
    return float_val(this-start);
}

const cst_val *cg_state_rindex(const cst_item *p)
{
    float end;
    int this;
    end = (float)ffeature_int(p,"R:mcep_link.parent.daughtern.frame_number");
    this = item_feat_int(p,"frame_number");
    return float_val(end-this);
}

const cst_val *cg_phone_place(const cst_item *p)
{
    float start, end;
    int this;
    start = (float)ffeature_int(p,"R:mcep_link.parent.R:segstate.parent.daughter1.R:mcep_link.daughter1.frame_number");
    end = (float)ffeature_int(p,"R:mcep_link.parent.R:segstate.parent.daughtern.R:mcep_link.daughtern.frame_number");
    this = item_feat_int(p,"frame_number");
    if ((end-start) == 0.0)
        return float_val(0.0);
    else
        return float_val((this-start)/(end-start));
}

const cst_val *cg_phone_index(const cst_item *p)
{
    float start;
    int this;
    start = (float)ffeature_int(p,"R:mcep_link.parent.R:segstate.parent.daughter1.R:mcep_link.daughter1.frame_number");
    this = item_feat_int(p,"frame_number");
    return float_val(this-start);
}

const cst_val *cg_phone_rindex(const cst_item *p)
{
    float end;
    int this;
    end = (float)ffeature_int(p,"R:mcep_link.parent.R:segstate.parent.daughtern.R:mcep_link.daughtern.frame_number");
    this = item_feat_int(p,"frame_number");
    return float_val(end-this);
}

void basic_ff_register(cst_features *ffunctions)
{
    ff_register(ffunctions, "ph_vc",ph_vc);
    ff_register(ffunctions, "ph_vlng",ph_vlng);
    ff_register(ffunctions, "ph_vheight",ph_vheight);
    ff_register(ffunctions, "ph_vfront",ph_vfront);
    ff_register(ffunctions, "ph_vrnd",ph_vrnd);
    ff_register(ffunctions, "ph_ctype",ph_ctype);
    ff_register(ffunctions, "ph_cplace",ph_cplace);
    ff_register(ffunctions, "ph_cvox",ph_cvox);

    ff_register(ffunctions, "lisp_cg_duration", cg_duration);
    ff_register(ffunctions, "lisp_cg_state_pos", cg_state_pos);
    ff_register(ffunctions, "lisp_cg_state_place", cg_state_place);
    ff_register(ffunctions, "lisp_cg_state_index", cg_state_index);
    ff_register(ffunctions, "lisp_cg_state_rindex", cg_state_rindex);
    ff_register(ffunctions, "lisp_cg_phone_place", cg_phone_place);
    ff_register(ffunctions, "lisp_cg_phone_index", cg_phone_index);
    ff_register(ffunctions, "lisp_cg_phone_rindex", cg_phone_rindex);

}
