/*************************************************************************/
/*                                                                       */
/*                   Carnegie Mellon University and                      */
/*                Centre for Speech Technology Research                  */
/*                     University of Edinburgh, UK                       */
/*                       Copyright (c) 1998-2001                         */
/*                        All Rights Reserved.                           */
/*                                                                       */
/*  Permission is hereby granted, free of charge, to use and distribute  */
/*  this software and its documentation without restriction, including   */
/*  without limitation the rights to use, copy, modify, merge, publish,  */
/*  distribute, sublicense, and/or sell copies of this work, and to      */
/*  permit persons to whom this work is furnished to do so, subject to   */
/*  the following conditions:                                            */
/*   1. The code must retain the above copyright notice, this list of    */
/*      conditions and the following disclaimer.                         */
/*   2. Any modifications must be clearly marked as such.                */
/*   3. Original authors' names are not deleted.                         */
/*   4. The authors' names are not used to endorse or promote products   */
/*      derived from this software without specific prior written        */
/*      permission.                                                      */
/*                                                                       */
/*  THE UNIVERSITY OF EDINBURGH, CARNEGIE MELLON UNIVERSITY AND THE      */
/*  CONTRIBUTORS TO THIS WORK DISCLAIM ALL WARRANTIES WITH REGARD TO     */
/*  THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY   */
/*  AND FITNESS, IN NO EVENT SHALL THE UNIVERSITY OF EDINBURGH, CARNEGIE */
/*  MELLON UNIVERSITY NOR THE CONTRIBUTORS BE LIABLE FOR ANY SPECIAL,    */
/*  INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER          */
/*  RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN  AN ACTION   */
/*  OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF     */
/*  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.       */
/*                                                                       */
/*************************************************************************/
/*             Author:  Alan W Black (awb@cs.cmu.edu)                    */
/*               Date:  January 2001                                     */
/*************************************************************************/
/*                                                                       */
/*  US F0 model LR features                                              */
/*                                                                       */
/*  Derived directly from the F0 LR model in University of Edinburgh's   */
/*  Festival Speech Synthesis Systems festival/lib/f2bf0lr.scm which in  */
/*  turn was trained from Boston University FM Radio Data Corpus         */
/*                                                                       */
/*************************************************************************/

#include "us_f0.h"

const us_f0_lr_term f0_lr_terms[] = {
    { "Intercept", 160.584961f, 169.183380f, 169.570374f, 0 },
    { "p.p.accent", 10.081770f, 4.923247f, 3.594771f, "H*" },
    { "p.p.accent", 3.358613f, 0.955474f, 0.432519f, "!H*" },
    { "p.p.accent", 4.144342f, 1.193597f, 0.235664f, "L+H*" },
    { "p.accent", 32.081028f, 16.603350f, 11.214208f, "H*" },
    { "p.accent", 18.090033f, 11.665814f, 9.619350f, "!H*" },
    { "p.accent", 23.255280f, 13.063298f, 9.084690f, "L+H*" },
    { "accent", 5.221081f, 34.517868f, 25.217588f, "H*" },
    { "accent", 10.159194f, 22.349655f, 13.759851f, "!H*" },
    { "accent", 3.645511f, 23.551548f, 17.635193f, "L+H*" },
    { "n.accent", -5.691933f, -1.914945f, 4.944848f, "H*" },
    { "n.accent", 8.265606f, 5.249441f, 7.398383f, "!H*" },
    { "n.accent", 0.861427f, -1.929947f, 1.683011f, "L+H*" },
    { "n.n.accent", -3.785701f, -6.147251f, -4.335797f, "H*" },
    { "n.n.accent", 7.013446f, 8.408949f, 5.656462f, "!H*" },
    { "n.n.accent", 2.637494f, 3.193500f, 0.263288f, "L+H*" },
    { "p.p.endtone", -3.531153f, 4.255273f, 10.274958f, "L-L%" },
    { "p.p.endtone", 8.258756f, 6.989573f, 10.446935f, "L-H%" },
    { "p.p.endtone", 5.836487f, 2.598854f, 6.104384f, "H-" },
    { "p.p.endtone", 11.213440f, 12.178307f, 14.182688f, "H-H%" },
    { "R:Syllable.p.endtone", -28.081360f, -4.397973f, 1.767454f, "L-L%" },
    { "R:Syllable.p.endtone", -6.585836f, 6.938086f, 8.750018f, "L-H%" },
    { "R:Syllable.p.endtone", 8.537044f, 6.162763f, 5.000340f, "H-" },
    { "R:Syllable.p.endtone", 4.243342f, 8.035727f, 10.913437f, "H-H%" },
    { "endtone", -9.333926f, -19.357903f, -12.637935f, "L-L%" },
    { "endtone", -0.937483f, -7.328882f, 8.747483f, "L-H%" },
    { "endtone", 9.472265f, 12.694193f, 15.165833f, "H-" },
    { "endtone", 14.256898f, 30.923397f, 50.190327f, "H-H%" },
    { "n.endtone", -13.084253f, -17.727785f, -16.965780f, "L-L%" },
    { "n.endtone", -5.471592f, -8.701685f, -7.833168f, "L-H%" },
    { "n.endtone", -0.095669f, -1.006439f, 4.701087f, "H-" },
    { "n.endtone", 4.933708f, 6.834498f, 10.349902f, "H-H%" },
    { "n.n.endtone", -14.993470f, -15.407530f, -15.369483f, "L-L%" },
    { "n.n.endtone", -11.352400f, -7.621437f, -7.052374f, "L-H%" },
    { "n.n.endtone", -5.551627f, -0.458837f, 2.207854f, "H-" },
    { "n.n.endtone", -0.661581f, 3.170632f, 5.271546f, "H-H%" },
    { "p.p.old_syl_break", -3.367677f, -4.196950f, -4.745862f, 0 },
    { "p.old_syl_break", 0.641755f, -5.176929f, -5.685178f, 0 },
    { "old_syl_break", -0.659002f, 0.047922f, -2.633291f, 0 },
    { "n.old_syl_break", 1.217358f, 2.153968f, 1.678340f, 0 },
    { "n.n.old_syl_break", 2.974502f, 2.577074f, 2.274729f, 0 },
    { "p.p.stress", 1.588098f, -2.368192f, -2.747198f, 0 },
    { "p.stress", 3.693430f, 1.080493f, 0.306724f, 0 },
    { "stress", 2.009843f, 1.135556f, -0.565613f, 0 },
    { "n.stress", 1.645560f, 2.447219f, 2.838327f, 0 },
    { "n.n.stress", 1.926870f, 1.318122f, 1.285244f, 0 },
    { "syl_in", 1.048362f, 0.291663f, 0.169955f, 0 },
    { "syl_out", 0.315553f, -0.411814f, -1.045661f, 0 },
    { "ssyl_in", -2.096079f, -1.643456f, -1.487774f, 0 },
    { "ssyl_out", 0.303531f, 0.580589f, 0.752405f, 0 },
    { "asyl_in", -4.257915f, -5.649243f, -5.081677f, 0 },
    { "asyl_out", -2.422424f, 0.489823f, 3.016218f, 0 },
    { "last_accent", -0.397647f, 0.216634f, 0.312900f, 0 },
    { "next_accent", -0.418613f, 0.244134f, 0.837992f, 0 },
    { "sub_phrases", -5.472055f, -5.758156f, -5.397805f, 0 },
    { 0, 0, 0, 0, 0 }
};

